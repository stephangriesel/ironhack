import React, { Component } from 'react';

class Welcome extends Component {
    // if logged in show link to topics else show welcome screen
    render() {
        return (
            <div>
            <h1>WELCOME</h1>
            </div>
        )
    }
}

export default Welcome

