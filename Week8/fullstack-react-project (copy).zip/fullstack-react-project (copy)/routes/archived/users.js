// const express = require('express');
// const router  = express.Router();

// // Login
// router.get('/login', (req, res, next) => {
//   res.render('login');
// });

// //Register
// router.get('/register', (req, res, next) => {
//     res.render('register');
//   });

// //Logout
// router.post("/logout", (req, res)=> {
//   // debugger
//   req.session.destroy()
//   res.send(200).json({message: "session destroyed"})
// })

// module.exports = router;
