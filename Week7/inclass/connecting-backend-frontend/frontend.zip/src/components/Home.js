import React, { Component } from 'react';

class Home extends Component {
    render() {
        return (
            <div>
                <h1>Welcome to my React Exercises Home Page</h1>
                <img src="https://media.giphy.com/media/3oKIPnAiaMCws8nOsE/giphy.gif" />
            </div>

        )
    }
}

export default Home;